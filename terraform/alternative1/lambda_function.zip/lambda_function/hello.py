import numpy as np

x = 3

result = np.sqrt(x)

print("Result = ", result)